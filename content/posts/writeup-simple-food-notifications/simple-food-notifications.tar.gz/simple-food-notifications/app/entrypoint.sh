#!/bin/bash
dnsmasq --user=root &
echo "nameserver 127.0.0.1" > /etc/resolv.conf
exec python /app/app.py
