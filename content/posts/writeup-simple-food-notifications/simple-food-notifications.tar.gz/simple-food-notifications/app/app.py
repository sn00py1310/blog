from flask import Flask, request, json, render_template
import os
import socket
import random
import threading
import time
import ipaddress
import logging
import secrets
import urllib3


app = Flask(__name__)
FLAG = "GPNCTF{HERE_IS_A_NICE_EXAMPLE_FLAG}"
with open("/flag", "r") as f:
    FLAG = f.read().strip()
notifications = dict()
last_requests = 0
rate_limit = 60


app.logger.setLevel(logging.DEBUG)

def randomId():
    return ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=10))

def randomBetween(a: int, b: int) -> int:
    return secrets.randbelow(b - a) + a

meal_messages = [
    "Our chef is a bit clumsy, but we are sure that your meal will be ready soon.",
    "Our chef is currently looking for the best ingredients for your meal, please wait patiently.",
    "Our chef is currently taking a break, but he will be back soon to work on your meal.",
    "The kitchen is on fire, but don't worry, our chef is a firefighter as well and will put it out soon to work on your meal.",
    "Our chef is currently juggling flaming swords, but he will be back soon to finish your meal.",
    "We forgot to turn on the stove, but our chef is currently looking for the switch, please wait patiently.",
    "We forgot to buy the ingredients for your meal, but our chef is currently on a shopping spree to get them, please wait patiently.",
    "Our chef is currently trying to fix a leaky faucet, but he will be back soon to finish your meal.",
    "Our chef is currently dealing with a kitchen emergency, but he will be back soon to finish your meal.",
    "Sorry, we are closing in 5 minutes, but our chef is currently trying to finish your meal before we close, please wait patiently.",
    "Sorry, we are closed, but you can order tomorrow again and our chef will be happy to cook your meal, please wait patiently.",
    "Our chef is currently on a secret mission, but he will be back soon to finish your meal.",
    "Sorry, our kitchen staff is in a fight with a rat, but our chef is currently trying to calm them down to finish your meal, please wait patiently.",
    "Our chef is currently training a new kitchen assistant, but he will be back soon to finish your meal.",
    "Our chef has a burn out from all your requests, please be patient with him, he will be back soon to finish your meal.",
    "What are we gonna do? And we gonna let it burn, burn, burn, burn.",
    "This meal is on fire. No really, our chef is currently trying to put out the fire, but he will be back soon to finish your meal.",
]


@app.route('/meal')
def meal_status():
    message = random.choice(meal_messages)
    return render_template('meal.html', title="Meal", message=message), 200


@app.route('/vip-meal')
def vip_meal():
    if request.remote_addr != "127.0.0.1":
        app.logger.warning(f"Your IP {request.remote_addr} is not whitelisted so see vip meals")
        return render_template('meal.html', message="You are not dressed appropriate to see even vip meals."), 401

    return render_template('meal.html', title="VIP Meal", message=f"Our chef cooked the beast meal for our vip customers, here is the flag {FLAG} with some caviar on top."), 200


@app.route('/order', methods=["POST"])
def meal_notification_create():
    global last_requests

    wait_time = rate_limit - (time.time() - last_requests)
    if wait_time > 0:
        return render_template('order.html', message=f"Sorry, but our staff is limited by their walking speed. We'll invest into faster staff but currently you have to wait at least {wait_time:.0f} seconds."), 429
    last_requests = time.time()


    id = randomId()
    url = request.form.get("url", default="", type=str)
    app.logger.info(f"Received notification request for {url} with id {id}")

    if (not url):
        return render_template('order.html', message="Sorry our staff would never find your non-existing url, this is rude."), 400
    
    notifications[id] = {
        "message": "We received your order and will notify you at your url as soon as it's ready.",
        "status": "RECEIVED"
    }
    t = threading.Thread(target=create_meal, args=(id,url,), daemon=True)
    t.start()

    return render_template('order.html', message=f'We received your order, it is going to be ready soon. Once the order is ready we will notify you at your notification url. <br>We even provide a notification status api, yours is <a href="/notification/{id}">{id}</a>.')



def create_meal(id, url, *args, **kwargs):
    global notifications
    if (len(notifications.keys()) > 100):
        notifications = dict()

    notifications[id] = {
        "message": f"We are working professionally on your meal and will notify you at {url} as soon as it's ready, please wait patiently.",
        "status": "COOKING"
    }
    time.sleep(randomBetween(5, 15)) # Let him cook

    try:
        addresses = socket.getaddrinfo(urllib3.util.parse_url(url).host, 80)
    except Exception as e:
        app.logger.error(f"Could not resolve hostname {urllib3.util.parse_url(url).host}, {e}")
        notifications[id] = {
            "message": f"Our server slipped on a banana peel while trying to notify you. We are sorry and are invested to clean better in the future.",
            "status": "FAILED"
        }
        return

    for addr in addresses:
        app.logger.info(f"Resolved {addr[4][0]}")
        if (not ipaddress.ip_address(addr[4][0]).is_global):
            notifications[id] = {
                "message": "Only staff is allowed to see mess in the kitchen, we don't want you to see the rats.",
                "status": "REJECTED"
            }
            return

    try:
        r = urllib3.request('GET', url, redirect=False, timeout=urllib3.Timeout(30))
        notifications[id] = {"message": r.data.decode('utf-8', errors='replace'), "status": "DONE"}
    except Exception as e:
        app.logger.error(f"Could not notify {url}, {e}")
        notifications[id] = {
            "message": f"Wait what, this is a new banana peel, we are sorry but we can't notify you at the moment. We will invest in better shoes for our staff to prevent this in the future.",
            "status": "FAILED"
        }


@app.route('/notification/<id>', methods=["GET"])
def meal_notification(id: str):
    notification = notifications.get(id, {})
    message = notification.get("message", "You need to order before you can even imagine to get a meal.")
    status = notification.get("status", "NO_ORDER")

    response = app.response_class(
        response=json.dumps({"id": id, "message": message, "status": status}),
        status=200,
        mimetype='application/json'
    )

    return response


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/shutdown')
def shutdown():
    # Shutting down will allow the remote instance to restart.
    os._exit(0)
    return "Shutting down the server..."

if __name__ == "__main__":
    port = int(os.environ.get('PORT', 80))
    app.run(host='0.0.0.0', port=port)
